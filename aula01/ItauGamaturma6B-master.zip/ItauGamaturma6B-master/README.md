# ItauGamaturma6B
Repositório para a turma 6B do treinamento Itau-Gama
