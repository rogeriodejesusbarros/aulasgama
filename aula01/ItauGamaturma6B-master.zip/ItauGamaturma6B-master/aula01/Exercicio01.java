public class Exercicio01 {

    public static void main(String[] args) {

        float valor1 = 15;
        int valor2 = 7;

        System.out.println( valor1 + valor2 );
        System.out.println( valor1 - valor2 );
        System.out.println( valor1 * valor2 );
        System.out.println( valor1 / valor2 );
        
    }

}