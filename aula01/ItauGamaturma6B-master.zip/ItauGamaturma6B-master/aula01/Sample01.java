/**
 * Este é meu primeiro código em Java
 * @author Emerson Paduan
 * 
 */

public class Sample01 {

    public static void main(String[] args) {
         //aqui vão as instruções

        //esta é a instrução para exibição da saída do programa
        System.out.println("Olá Mundo! Meu primeiro programa!");

        System.out.println("2 + 3"); // entre aspas é texto

        System.out.println(2 + 3); //fora das aspas será interpretado
        
        //error - linha vermelha
        //warning - aviso de possivel problema
    }
    
}

