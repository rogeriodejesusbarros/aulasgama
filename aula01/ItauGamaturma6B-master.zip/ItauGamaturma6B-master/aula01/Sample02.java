public class Sample02 {
    public static void main(String[] args) {

        // operadores aritméticos: + - / * % (resto da divisão)

        // atalho para executar (CTRL + F5)

        //ALT + SHIFT + F : alinha o código

        // abreviação: syso
        System.out.println(2 + 3 * 4);

        System.out.println((2 + 3) * 4);

        System.out.println(15 % 2);

        // + com texto faz a concatenação
        System.out.println("A soma de 2 + 3 = " + (2 + 3));

        // \n quebra a linha
        System.out.println("Este \ntexto deve \nsair em várias\n linhas.");
    }

}